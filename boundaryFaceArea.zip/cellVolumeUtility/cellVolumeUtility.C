#include "fvCFD.H"
#include "volFields.H"
#include "surfaceFields.H"

int main(int argc, char *argv[])
{
    // Initialize OpenFOAM
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"

    Info << "Calculating boundary face areas and writing as a volScalarField..." << endl;

    // Create a volScalarField for storing boundary face areas
    volScalarField boundaryFaceArea
    (
        IOobject
        (
            "boundaryFaceArea",
            runTime.timeName(),
            mesh,
            IOobject::NO_READ,
            IOobject::AUTO_WRITE
        ),
        mesh,
        dimensionedScalar("zero", dimArea, 0.0)
    );

    // Iterate over all boundary patches
    forAll(mesh.boundary(), patchI)
    {
        const fvPatch& boundaryPatch = mesh.boundary()[patchI];  // Use fvPatch directly
        word patchName = boundaryPatch.name();

        Info << "Processing patch: " << patchName << endl;

        // Get the number of faces in the boundary patch
        label nFaces = boundaryPatch.size();

        // Create a new scalar field for this patch's face areas
        scalarField faceAreas(nFaces, 0.0);

        // Loop through all faces in the patch
        for (label faceI = 0; faceI < nFaces; ++faceI)
        {
            // Get the face area for the boundary face
            scalar area = boundaryPatch.magSf()[faceI];  // Surface area value

            // Assign the area to the faceAreas field
            faceAreas[faceI] = area; // Assign area
        }

             
          forAll (mesh.boundaryMesh(), patchI)
           {
            forAll(boundaryFaceArea.boundaryFieldRef()[patchI], faceI)
            {
           
              boundaryFaceArea.boundaryFieldRef()[patchI][faceI] =  boundaryPatch.magSf()[faceI];
            }
          }





        // Get the mutable reference to the fvPatchField for this patch
//        fvPatchField<double>& boundaryField = boundaryFaceArea.boundaryField()[patchI];

        // Ensure the size matches
  //      boundaryField.resize(nFaces);

        // Assign the computed face areas to the boundary field
//        for (label faceI = 0; faceI < nFaces; ++faceI)
 //       {
 //           boundaryField[faceI] = faceAreas[faceI]; // Assign area
 //       }
    }

    // Write the volScalarField
    boundaryFaceArea.write();
    Info << "Boundary face areas written as a volScalarField 'boundaryFaceArea'." << endl;

    return 0;
}

